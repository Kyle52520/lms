<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										<img id="developers" src="admin/images/jkev.jpg" class="img-circle">
										<hr>
										<p>Name: Kyle Halili</p>
										<p>Address: Orani Bataan</p>
										<p>Email: kylehalili525@gmail.com</p>
										<p>Position: Programmer</p>
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/jelyn.jpg" class="img-circle">
								<hr>
																				<p>Name: Sean Christopher</p>

										<p>Address: Balanga City</p>
										<p>Email: seanchristopher@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/jorge.jpg" class="img-circle">
								<hr>
												<p>Name: Joyce Factorian</p>
										<p>Address: Orani Bataan</p>
										<p>Email: joycefactorian@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/mich.jpg" class="img-circle">
								<hr>
												<p>Name: Nomer Aleviado</p>
										<p>Address: Balanga City</p>
										<p>Email: nomeraleviado@gmail.com</p>
										<p>Position: Project Advisor</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>