<center>
		<footer>
		
		<p>SkillForge Copyright 2024</p>
			<!-- <p>Programmed by: Kyle Halili BSCS-401</p> -->
		</footer>
</center>

